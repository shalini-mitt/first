package com.example.consistent_car

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
